﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace linq_1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        DataBaseContext dataBase = new DataBaseContext();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string[] nameRandom = { "Илья", "Роман", "Саша", "Кирилл", "Василий" };
            string[] surnameRandom = { "Пятков", "Шишкин", "Поветкин", "Ушаков", "Булачов", "Михайлов","Зайцев", "Васильев" };
            List<People> people = new List<People>();
            Random rand = new Random();
            for (int i = 0; i <= 5; i++)
            { 
                People p = new People()
            {
                FirstName = nameRandom[rand.Next(nameRandom.Length)],
                SurName = surnameRandom[rand.Next(nameRandom.Length)],
                Birthday = new DateTime(rand.Next(1990,2003),rand.Next(1,12),rand.Next(1,31)),
                Rise = rand.NextDouble()*rand.Next(100,190),
                Weight = rand.NextDouble() * rand.Next(40, 100)
            };

                people.Add(p);
                  }
            lvGeneratePeole.ItemsSource = people;
            dataBase.peoples.AddRange(people);
            dataBase.SaveChanges();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataBase.peoples.OrderBy(Weight => Weight.Weight).ToList();
            string nameW = $"Количество людей в базе данных: {dataBase.peoples.Count()}";
            MessageBox.Show(nameW);

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataBase.peoples.OrderBy(Rise => Rise.Rise).ToList();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataBase.peoples.OrderByDescending(Birthday => Birthday.Birthday).ToList();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            tdSr.Text = $"Среднее значение веса: {dataBase.peoples.Average(p => p.Weight)}";
            tbCount.Text = $"Имя человека с максимальным вессом - {dataBase.peoples.Max(p => p.FirstName)}. Вес - {dataBase.peoples.Max(p => p.Weight)} ";

        }
    }
}

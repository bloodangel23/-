﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace linq_1
{
    public class People
    {
        public int Id
        {
            get; set;
        }
        public string FirstName
        {
            get; set;
        }
        public string SurName
        {
            get; set;
        }
        public DateTime Birthday
        {
            get; set;
        }
        public double Rise
        {
            get; set;
        }
        public double Weight
        {
            get; set;
        }
    }
}
